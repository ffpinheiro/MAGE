package MAGE.mage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MageApplicationTests {

	@Test
	void contextLoads() {
	}

}
